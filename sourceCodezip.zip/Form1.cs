﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace ezCopy
{
    public partial class ezCopy : Form
    {
        public ezCopy()
        {
            InitializeComponent();
        }

        private void ezCopy_Load(object sender, EventArgs e)
        {
        }

        private void fileCopyBTN_Click(object sender, EventArgs e)
        {
            // OpenFileDialog 열기
            OpenFileDialog openFileDialog = new OpenFileDialog();
            // 다중 선택 활성화
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // FolderBrowserDialog 열기
                FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
                if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = "파일 복사 중...";

                    foreach (string file in openFileDialog.FileNames)
                    {
                        string fileName = Path.GetFileName(file);
                        string destinationPath = Path.Combine(folderBrowserDialog.SelectedPath, fileName);

                        try
                        {
                            // 파일 복사
                            File.Copy(file, destinationPath);
                        }
                        catch (IOException ex)
                        {
                            MessageBox.Show("파일 복사하지 못했습니다. 오류 메시지: " + ex.Message);
                        }
                    }

                    textBox1.Text = "파일 복사 완료";

                    MessageBox.Show("파일 복사 완료");
                }
            }
        }

        private void folderCopyBTN_Click(object sender, EventArgs e)
        {
            // 소스 디렉토리 및 타겟 디렉토리 경로를 윈도우 다이얼로그 선택
            string sourcePath = SelectFolderDialog("소스 폴더 선택");
            string targetPath = SelectFolderDialog("저장 폴더 선택");

            textBox1.Text = "폴더 복사 중...";

            // 파일 및 폴더 복사 수행
            CopyFilesRecursively(new DirectoryInfo(sourcePath), new DirectoryInfo(targetPath));

            textBox1.Text = "폴더 복사 완료";

            // 복사 완료 메시지 출력
            MessageBox.Show("폴더 복사 완료");
        }

        private static void CopyFilesRecursively(DirectoryInfo source, DirectoryInfo target)
        {
            // 디렉토리 없으면 생성
            if (!Directory.Exists(target.FullName))
            {
                Directory.CreateDirectory(target.FullName);
            }

            // 폴더 내 모든 파일 복사
            foreach (FileInfo fileInfo in source.GetFiles())
            {
                if ((fileInfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                {
                    string path = Path.Combine(target.FullName, fileInfo.Name);
                    fileInfo.CopyTo(path, true);
                    //textBox1.Text($"File copied: {path}");
                }
            }

            // 모든 하위 폴더 내 파일 복사
            foreach (DirectoryInfo sourceSubDir in source.GetDirectories())
            {
                if ((sourceSubDir.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                {
                    DirectoryInfo targetSubDir = target.CreateSubdirectory(sourceSubDir.Name);
                    CopyFilesRecursively(sourceSubDir, targetSubDir);
                }
            }
        }

        // 폴더 다이얼로그

        private static string SelectFolderDialog(string title)
        {
            using (var dialog = new System.Windows.Forms.FolderBrowserDialog())
            {
                dialog.Description = title;

                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    return dialog.SelectedPath;
                }
                else
                {
                    throw new Exception("폴더 미선택. 폴더를 선택하세요");
                }
            }
        }

        //종료

        private void exitBTN_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
